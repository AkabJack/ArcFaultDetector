package com.example.arcdetector;
import static android.app.ProgressDialog.show;

import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkRequest;
import android.net.TransportInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.Manifest;

import androidx.annotation.NonNull;
import androidx.compose.ui.state.ToggleableState;
import androidx.core.app.ActivityCompat;

import com.github.mikephil.charting.charts.LineChart;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.LineData;
import com.github.mikephil.charting.data.LineDataSet;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    final String SERVER_URL = "http://192.168.4.1/data";
    final String SERVER_GRAPH_URL = "http://192.168.4.1/graph";
    final String SSID_NAME = "ArcDetectorHotspot";
    private volatile boolean isNetworkBound = false;
    private volatile Network boundNetwork = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LOCKED);
        setContentView(R.layout.my_layout);

        requestLocationPermissionIfNeeded();
        bindToWifiNetwork(this);

        setupButton(R.id.AMx10, "AMx10");
        setupButton(R.id.AMx1, "AMx1");
        setupButton(R.id.AMx5, "AMx5");
        setupButton(R.id.ATx5, "ATx5");
        setupButton(R.id.ATx10, "ATx10");
        setupButton(R.id.STOP_BTN, "STOP");
        setupButton(R.id.START_BTN, "START");

        setupInputButton(R.id.FREQ, R.id.FREQ_NUM_BOX, "FREQ");
        setupInputButton(R.id.POWER, R.id.POW_NUM_BOX, "POW");
        setupButtonGraph(R.id.LOAD_GRAPH, "R_POW");
    }

    private void setupButton(int buttonId, String command) {
        Button btn = findViewById(buttonId);
        btn.setOnClickListener(v -> new Thread(() -> sendCommand(command)).start());
    }

    private void setupButtonGraph(int buttonId, String graph_id) {
        Button btn = findViewById(buttonId);
        btn.setOnClickListener(v -> new Thread(() -> {
            sendCommand(graph_id);
            loadGraphData();
        }).start());
    }

    private void setupInputButton(int buttonId, int box_id, String command){
        Button Btn = findViewById(buttonId);
        EditText Box = findViewById(box_id);
        Btn.setOnClickListener(v -> {
            String value = Box.getText().toString().trim();
            if(!value.isEmpty()){
                new Thread(() -> sendCommand(command)).start();
                try{
                    Thread.sleep(50);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                new Thread(() -> sendCommand(value)).start();
            } else {
                runOnUiThread(() -> Toast.makeText(this, "Please enter a value for the command", Toast.LENGTH_SHORT).show());
            }
        });
    }

    private void sendCommand(String command) {
        if (isNetworkBound) {
        try {
                URL url = new URL(SERVER_URL);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setDoOutput(true);
                conn.setRequestProperty("Content-Type", "text/plain; charset=UTF-8");

                try (OutputStream os = conn.getOutputStream()) {
                    BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os, "UTF-8"));
                    writer.write(command);
                    writer.flush();
                }
                int responseCode = conn.getResponseCode();
                runOnUiThread(() -> Toast.makeText(this, "Sent: " + command + " | Response: " + responseCode, Toast.LENGTH_SHORT).show());
                conn.disconnect();

            } catch(IOException e){
                e.printStackTrace();
                runOnUiThread(() -> Toast.makeText(this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show());
            }
        } else {
            Log.d("BUTTON","Not bound to network");
        }
    }

    private void loadGraphData() {
        if(!isNetworkBound || boundNetwork == null){
            Toast.makeText(this, "Not bound to the right network", Toast.LENGTH_SHORT).show();
            return;
        } else {
           new Thread(() -> {
               try {
                   sendCommand("R_POW");
                   try{
                       Thread.sleep(1000);
                   } catch (InterruptedException e) {
                       e.printStackTrace();
                   }

                   URL url = new URL(SERVER_GRAPH_URL);
                   HttpURLConnection conn = (HttpURLConnection) boundNetwork.openConnection(url);
                   conn.setRequestMethod("GET");

                   BufferedReader reader = new BufferedReader( new InputStreamReader(conn.getInputStream()));
                   StringBuilder response = new StringBuilder();
                   String line;
                   while ((line = reader.readLine()) != null) {
                       response.append(line);
                   }
                   reader.close();

                   String jsonData = response.toString();
                   JSONArray JSONArray = new JSONArray(jsonData);

                   List<Entry> entries = new ArrayList<>();
                   for (int i = 0; i < JSONArray.length(); i++) {
                       float value = (float) JSONArray.getDouble(i);
                       entries.add(new Entry(i, value));
                   }

                   runOnUiThread(() -> {
                       LineChart chart = findViewById(R.id.graph);
                       LineDataSet dataSet = new LineDataSet(entries, "Signal Data");
                       dataSet.setDrawValues(false);
                       dataSet.setDrawCircles(false);
                       chart.setData(new LineData(dataSet));
                       chart.invalidate();
                   });
               } catch (Exception e){
                   e.printStackTrace();
                   runOnUiThread(() -> Toast.makeText(this, "GRAPH ERROR: " + e.getMessage(), Toast.LENGTH_SHORT).show());
               }
           }).start();
        }
    }
    private void bindToWifiNetwork(Context context) {//we already know the SSID!!
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

        NetworkRequest request = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .build();

        ConnectivityManager.NetworkCallback callback = new ConnectivityManager.NetworkCallback(ConnectivityManager.NetworkCallback.FLAG_INCLUDE_LOCATION_INFO){
            @Override
            public void onCapabilitiesChanged(@NonNull Network network, NetworkCapabilities caps){
              TransportInfo ti = caps.getTransportInfo();
              if(ti instanceof WifiInfo){
                  WifiInfo wi = (WifiInfo) ti;
                  String ssid = wi.getSSID().replace("\"", "");
                  Log.d("SSID", "Connected to SSID: " + ssid);
                  if(ssid.equals(SSID_NAME)){
                      boundNetwork = network;
                      isNetworkBound = true;
                      connectivityManager.bindProcessToNetwork(network);
                      Toast.makeText(context, "Bound to right network" , Toast.LENGTH_SHORT).show();
                  } else {
                      Toast.makeText(context, "Wrong network" , Toast.LENGTH_SHORT).show();
                  }
              }
          }
        };
        connectivityManager.registerNetworkCallback(request, callback);
    }

    private void requestLocationPermissionIfNeeded() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
        }
    }
}
